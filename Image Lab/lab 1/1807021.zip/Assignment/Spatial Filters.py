import numpy as np
import cv2


def gaussian(m,n,sigma):
    gaussian = np.zeros((m,n))
    m = m//2
    n = n//2
    
    for x in range(-m,m+1):
        for y in range(-n,n+1):
            
            x1 = (2*np.pi * sigma**2)
            x2 = np.exp(-(x**2 + y**2)/(2*sigma**2))
            
            gaussian[x+m,y+n] = (1/x1) * x2
    
    return gaussian
    
def conv(img,filt):
    S = img.shape
    F = filt.shape

    R = S[0] + F[0] -1
    C = S[1] + F[1] -1

    Z = np.zeros((R,C))


    for x in range(S[0]):
        for y in range(S[1]):
            Z[x+int((F[0]-1)/2), y+int((F[1]-1)/2)] = img[x,y]


    for i in range(S[0]):
        for j in range(S[1]):
            k = Z[i:i+F[0],j:j+F[1]]
            sum = 0
            for x in range(F[0]):
                for y in range (F[1]):
                        sum += (k[x][y] * filt[-x][-y])

            img[i,j] = sum
    return img

def median(img,filt):
    S = img.shape
    F = filt.shape

    R = S[0] + F[0] -1
    C = S[1] + F[1] -1

    Z = np.zeros((R,C))


    for x in range(S[0]):
        for y in range(S[1]):
            Z[x+int((F[0]-1)/2), y+int((F[1]-1)/2)] = img[x,y]


    for i in range(S[0]):
        for j in range(S[1]):
            k = Z[i:i+F[0],j:j+F[1]]
            v = []
            for x in range(F[0]):
                for y in range (F[1]):
                    v.append(k[x][y])
            v.sort()
            img[i,j] = v[int(len(v)/2)]
            v.clear()
    return img

img = cv2.imread("Lena.jpg", cv2.IMREAD_GRAYSCALE)
cv2.imshow("Original",img) 

#plt.imshow(img,'gray')
#plt.show()


#Mean
filt = np.array([
        [1,1,1,1,1],
        [1,1,1,1,1],
        [1,1,1,1,1],
        [1,1,1,1,1],
        [1,1,1,1,1]])/25
img = conv(img, filt)
cv2.imshow("Mean",img)


#Median
filt = np.array([[0,0,0,0,0],
                 [0,0,0,0,0],
                 [0,0,0,0,0],
                 [0,0,0,0,0],
                 [0,0,0,0,0]]) 
img = median(img,filt)
cv2.imshow("Median",img)


#Gaussian
#sigma = int(input("Enter sigma value: "))
sigma = 3
m = 5*sigma
if m%2==0:
    m += 1
filt = gaussian(m,m,sigma)
img = conv(img, filt)
cv2.imshow("Gaussian",img)


#Laplace
filt = np.array([
        [0,1,0],
        [1,-4,1],
        [0,1,0]])
img = conv(img,filt)
cv2.imshow("Laplacian",img)

#Sobel
filt = np.array([
        [1,2,1],
        [0,0,0],
        [-1,-2,-1]])
img = conv(img, filt)
cv2.imshow("Sobel1",img)

filt = np.array([
        [1,0,-1],
        [2,0,-2],
        [1,0,-1]])
img = conv(img, filt)
cv2.imshow("Sobel2",img)
    

#print(filt)


        
#cv2.imshow("final",img)

#plt.imshow(img,'gray')
#plt.show()


cv2.waitKey(0)
cv2.destroyAllWindows()

